package com.example.configInicialEcomponentes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigInicialEcomponentesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigInicialEcomponentesApplication.class, args);
	}

}
